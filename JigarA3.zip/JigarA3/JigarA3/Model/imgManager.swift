//
//  imgManager.swift
//  Created by user202348 on 10/25/21.
//  Copyright © 2021 user202348. All rights reserved.

import Foundation

class imgManager
{
    private var imageList = [image]()
    //appending new image in the list
    func addNewImage(i:image)
    {
        imageList.append(i)
    }
    //get all the added image.
    func getImageList()->[image]{
        return imageList
    }
}
