//
//  img.swift

//  Created by user202348 on 10/25/21.
//  Copyright © 2021 user202348. All rights reserved.


import Foundation

class img
{
    var imageName:String=""
    var imageUrl:String=""
    
    init(a:String,b:String) {
        imageName=a
        imageUrl=b
    }
}
